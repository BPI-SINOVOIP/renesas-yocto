/* SPDX-License-Identifier: GPL-2.0 WITH Linux-syscall-note */
/*
 *
 * (C) COPYRIGHT 2015-2024 ARM Limited. All rights reserved.
 *
 * This program is free software and is provided to you under the terms of the
 * GNU General Public License version 2 as published by the Free Software
 * Foundation, and any use by you of this program is subject to the terms
 * of such GNU license.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, you can access it online at
 * http://www.gnu.org/licenses/gpl-2.0.html.
 *
 */

#ifndef _UAPI_KBASE_GPU_COHERENCY_H_
#define _UAPI_KBASE_GPU_COHERENCY_H_

#if defined(__cplusplus)
extern "C" {
#endif

#define COHERENCY_ACE_LITE 0U
#define COHERENCY_ACE 1U
#define COHERENCY_NONE 31U
#define COHERENCY_FEATURE_BIT(x) (1U << (x))

#if defined(__cplusplus)
}
#endif

#endif /* _UAPI_KBASE_GPU_COHERENCY_H_ */
